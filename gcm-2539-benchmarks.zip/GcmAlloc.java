import java.lang.management.ManagementFactory;
import java.security.Security;
import java.util.Arrays;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class GcmAlloc {
    private static final SecretKeySpec KEY = new SecretKeySpec(new byte[32], "AES");
    private static final byte[] NONCE = new byte[12];
    private static final byte[] FIXTURE_NONCE = new byte[12];
    private static long sequence;
    private static volatile byte[] sink;

    private static byte[] crypt(boolean encryption, byte[] input) throws Exception {
        if (encryption) {
            long next = ++sequence;
            for (int i = 0; i < 8; i++) NONCE[11 - i] = (byte)(next >>> (8 * i));
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding", "BC");
        cipher.init(encryption ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, KEY,
            new GCMParameterSpec(128, encryption ? NONCE : FIXTURE_NONCE));
        return cipher.doFinal(input);
    }

    public static void main(String[] args) throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        var bean = (com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();
        if (!bean.isThreadAllocatedMemorySupported()) throw new IllegalStateException("no allocation counter");
        bean.setThreadAllocatedMemoryEnabled(true);
        long thread = Thread.currentThread().threadId();
        System.out.println("direction,plaintextBytes,round,allocatedBytesPerOperation");
        for (int size : new int[]{0, 1, 15, 16, 17, 1024, 16384, 262144, 1048576}) {
            byte[] plain = new byte[size];
            for (int i = 0; i < size; i++) plain[i] = (byte)(31 * i + 7);
            Cipher fixture = Cipher.getInstance("AES/GCM/NoPadding", "BC");
            fixture.init(Cipher.ENCRYPT_MODE, KEY, new GCMParameterSpec(128, FIXTURE_NONCE));
            byte[] encrypted = fixture.doFinal(plain);
            Cipher reference = Cipher.getInstance("AES/GCM/NoPadding", "SunJCE");
            reference.init(Cipher.ENCRYPT_MODE, KEY, new GCMParameterSpec(128, FIXTURE_NONCE));
            if (!Arrays.equals(encrypted, reference.doFinal(plain))) throw new AssertionError("ciphertext mismatch");
            if (!Arrays.equals(plain, crypt(false, encrypted))) throw new AssertionError("plaintext mismatch");
            for (boolean enc : new boolean[]{true, false}) {
                byte[] input = enc ? plain : encrypted;
                for (int i = 0; i < 300; i++) sink = crypt(enc, input);
                for (int round = 0; round < 3; round++) {
                    long before = bean.getThreadAllocatedBytes(thread);
                    for (int i = 0; i < 200; i++) sink = crypt(enc, input);
                    double allocated = (bean.getThreadAllocatedBytes(thread) - before) / 200.0;
                    System.out.printf(Locale.ROOT, "%s,%d,%d,%.2f%n", enc ? "encrypt" : "decrypt", size, round, allocated);
                }
            }
        }
    }
}
