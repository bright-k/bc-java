package bench;

import java.security.Security;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.openjdk.jmh.annotations.*;

@State(Scope.Thread)
@BenchmarkMode(Mode.Throughput)
@OutputTimeUnit(TimeUnit.SECONDS)
public class GcmBenchmark {
    @Param({"0", "16", "1024", "16384", "262144", "1048576"})
    public int size;
    @Param({"encrypt", "decrypt"})
    public String direction;
    private SecretKeySpec key;
    private byte[] nonce;
    private byte[] input;
    private long sequence;

    @Setup(Level.Trial)
    public void setup() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        key = new SecretKeySpec(new byte[32], "AES");
        nonce = new byte[12];
        byte[] plain = new byte[size];
        for (int i = 0; i < size; i++) plain[i] = (byte)(31 * i + 7);
        Cipher fixture = Cipher.getInstance("AES/GCM/NoPadding", "BC");
        fixture.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, nonce));
        byte[] encrypted = fixture.doFinal(plain);
        Cipher reference = Cipher.getInstance("AES/GCM/NoPadding", "SunJCE");
        reference.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, nonce));
        if (!Arrays.equals(encrypted, reference.doFinal(plain))) throw new AssertionError("ciphertext mismatch");
        input = direction.equals("encrypt") ? plain : encrypted;
    }

    @Benchmark
    public byte[] crypt() throws Exception {
        boolean encryption = direction.equals("encrypt");
        if (encryption) {
            long next = ++sequence;
            for (int i = 0; i < 8; i++) nonce[11 - i] = (byte)(next >>> (8 * i));
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding", "BC");
        cipher.init(encryption ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, key,
            new GCMParameterSpec(128, nonce));
        return cipher.doFinal(input);
    }
}
